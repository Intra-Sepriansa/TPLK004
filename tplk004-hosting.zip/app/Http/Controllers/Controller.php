<?php

namespace App\Http\Controllers;

use DateTimeInterface;
use Illuminate\Support\Carbon;

abstract class Controller
{
    protected function formatDisplayTime(?DateTimeInterface $value, string $format = 'Y-m-d H:i:s'): ?string
    {
        if (! $value) {
            return null;
        }

        $timezone = (string) config('app.display_timezone', config('app.timezone', 'UTC'));
        $carbon = $value instanceof Carbon ? $value->copy() : Carbon::instance($value);

        return $carbon->setTimezone($timezone)->format($format);
    }
}
