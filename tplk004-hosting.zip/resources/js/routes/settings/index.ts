import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\SettingsController::update
* @see app/Http/Controllers/Admin/SettingsController.php:12
* @route '/settings'
*/
export const update = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/settings',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\SettingsController::update
* @see app/Http/Controllers/Admin/SettingsController.php:12
* @route '/settings'
*/
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SettingsController::update
* @see app/Http/Controllers/Admin/SettingsController.php:12
* @route '/settings'
*/
update.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Admin\SettingsController::update
* @see app/Http/Controllers/Admin/SettingsController.php:12
* @route '/settings'
*/
const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\SettingsController::update
* @see app/Http/Controllers/Admin/SettingsController.php:12
* @route '/settings'
*/
updateForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Admin\SettingsController::geofence
* @see app/Http/Controllers/Admin/SettingsController.php:31
* @route '/settings/geofence'
*/
export const geofence = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: geofence.url(options),
    method: 'patch',
})

geofence.definition = {
    methods: ["patch"],
    url: '/settings/geofence',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\SettingsController::geofence
* @see app/Http/Controllers/Admin/SettingsController.php:31
* @route '/settings/geofence'
*/
geofence.url = (options?: RouteQueryOptions) => {
    return geofence.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SettingsController::geofence
* @see app/Http/Controllers/Admin/SettingsController.php:31
* @route '/settings/geofence'
*/
geofence.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: geofence.url(options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Admin\SettingsController::geofence
* @see app/Http/Controllers/Admin/SettingsController.php:31
* @route '/settings/geofence'
*/
const geofenceForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: geofence.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\SettingsController::geofence
* @see app/Http/Controllers/Admin/SettingsController.php:31
* @route '/settings/geofence'
*/
geofenceForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: geofence.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

geofence.form = geofenceForm

const settings = {
    update: Object.assign(update, update),
    geofence: Object.assign(geofence, geofence),
}

export default settings