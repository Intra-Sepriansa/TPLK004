import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import absenBc4e8c from './absen'
import profile937a89 from './profile'
import password9cfa90 from './password'
/**
* @see \App\Http\Controllers\User\AbsensiController::absen
* @see app/Http/Controllers/User/AbsensiController.php:25
* @route '/user/absen'
*/
export const absen = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: absen.url(options),
    method: 'get',
})

absen.definition = {
    methods: ["get","head"],
    url: '/user/absen',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\User\AbsensiController::absen
* @see app/Http/Controllers/User/AbsensiController.php:25
* @route '/user/absen'
*/
absen.url = (options?: RouteQueryOptions) => {
    return absen.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\AbsensiController::absen
* @see app/Http/Controllers/User/AbsensiController.php:25
* @route '/user/absen'
*/
absen.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: absen.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\User\AbsensiController::absen
* @see app/Http/Controllers/User/AbsensiController.php:25
* @route '/user/absen'
*/
absen.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: absen.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\User\AbsensiController::absen
* @see app/Http/Controllers/User/AbsensiController.php:25
* @route '/user/absen'
*/
const absenForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: absen.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\User\AbsensiController::absen
* @see app/Http/Controllers/User/AbsensiController.php:25
* @route '/user/absen'
*/
absenForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: absen.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\User\AbsensiController::absen
* @see app/Http/Controllers/User/AbsensiController.php:25
* @route '/user/absen'
*/
absenForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: absen.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

absen.form = absenForm

/**
* @see \App\Http\Controllers\User\AbsensiController::rekapan
* @see app/Http/Controllers/User/AbsensiController.php:295
* @route '/user/rekapan'
*/
export const rekapan = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: rekapan.url(options),
    method: 'get',
})

rekapan.definition = {
    methods: ["get","head"],
    url: '/user/rekapan',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\User\AbsensiController::rekapan
* @see app/Http/Controllers/User/AbsensiController.php:295
* @route '/user/rekapan'
*/
rekapan.url = (options?: RouteQueryOptions) => {
    return rekapan.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\AbsensiController::rekapan
* @see app/Http/Controllers/User/AbsensiController.php:295
* @route '/user/rekapan'
*/
rekapan.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: rekapan.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\User\AbsensiController::rekapan
* @see app/Http/Controllers/User/AbsensiController.php:295
* @route '/user/rekapan'
*/
rekapan.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: rekapan.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\User\AbsensiController::rekapan
* @see app/Http/Controllers/User/AbsensiController.php:295
* @route '/user/rekapan'
*/
const rekapanForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: rekapan.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\User\AbsensiController::rekapan
* @see app/Http/Controllers/User/AbsensiController.php:295
* @route '/user/rekapan'
*/
rekapanForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: rekapan.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\User\AbsensiController::rekapan
* @see app/Http/Controllers/User/AbsensiController.php:295
* @route '/user/rekapan'
*/
rekapanForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: rekapan.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

rekapan.form = rekapanForm

/**
* @see \App\Http\Controllers\User\AbsensiController::buktiMasuk
* @see app/Http/Controllers/User/AbsensiController.php:334
* @route '/user/bukti-masuk'
*/
export const buktiMasuk = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: buktiMasuk.url(options),
    method: 'get',
})

buktiMasuk.definition = {
    methods: ["get","head"],
    url: '/user/bukti-masuk',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\User\AbsensiController::buktiMasuk
* @see app/Http/Controllers/User/AbsensiController.php:334
* @route '/user/bukti-masuk'
*/
buktiMasuk.url = (options?: RouteQueryOptions) => {
    return buktiMasuk.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\AbsensiController::buktiMasuk
* @see app/Http/Controllers/User/AbsensiController.php:334
* @route '/user/bukti-masuk'
*/
buktiMasuk.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: buktiMasuk.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\User\AbsensiController::buktiMasuk
* @see app/Http/Controllers/User/AbsensiController.php:334
* @route '/user/bukti-masuk'
*/
buktiMasuk.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: buktiMasuk.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\User\AbsensiController::buktiMasuk
* @see app/Http/Controllers/User/AbsensiController.php:334
* @route '/user/bukti-masuk'
*/
const buktiMasukForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: buktiMasuk.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\User\AbsensiController::buktiMasuk
* @see app/Http/Controllers/User/AbsensiController.php:334
* @route '/user/bukti-masuk'
*/
buktiMasukForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: buktiMasuk.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\User\AbsensiController::buktiMasuk
* @see app/Http/Controllers/User/AbsensiController.php:334
* @route '/user/bukti-masuk'
*/
buktiMasukForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: buktiMasuk.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

buktiMasuk.form = buktiMasukForm

/**
* @see \App\Http\Controllers\User\ProfileController::profile
* @see app/Http/Controllers/User/ProfileController.php:14
* @route '/user/profile'
*/
export const profile = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: profile.url(options),
    method: 'get',
})

profile.definition = {
    methods: ["get","head"],
    url: '/user/profile',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\User\ProfileController::profile
* @see app/Http/Controllers/User/ProfileController.php:14
* @route '/user/profile'
*/
profile.url = (options?: RouteQueryOptions) => {
    return profile.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\ProfileController::profile
* @see app/Http/Controllers/User/ProfileController.php:14
* @route '/user/profile'
*/
profile.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: profile.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\User\ProfileController::profile
* @see app/Http/Controllers/User/ProfileController.php:14
* @route '/user/profile'
*/
profile.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: profile.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\User\ProfileController::profile
* @see app/Http/Controllers/User/ProfileController.php:14
* @route '/user/profile'
*/
const profileForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: profile.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\User\ProfileController::profile
* @see app/Http/Controllers/User/ProfileController.php:14
* @route '/user/profile'
*/
profileForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: profile.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\User\ProfileController::profile
* @see app/Http/Controllers/User/ProfileController.php:14
* @route '/user/profile'
*/
profileForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: profile.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

profile.form = profileForm

/**
* @see \App\Http\Controllers\User\PasswordController::password
* @see app/Http/Controllers/User/PasswordController.php:15
* @route '/user/password'
*/
export const password = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: password.url(options),
    method: 'get',
})

password.definition = {
    methods: ["get","head"],
    url: '/user/password',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\User\PasswordController::password
* @see app/Http/Controllers/User/PasswordController.php:15
* @route '/user/password'
*/
password.url = (options?: RouteQueryOptions) => {
    return password.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\PasswordController::password
* @see app/Http/Controllers/User/PasswordController.php:15
* @route '/user/password'
*/
password.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: password.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\User\PasswordController::password
* @see app/Http/Controllers/User/PasswordController.php:15
* @route '/user/password'
*/
password.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: password.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\User\PasswordController::password
* @see app/Http/Controllers/User/PasswordController.php:15
* @route '/user/password'
*/
const passwordForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: password.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\User\PasswordController::password
* @see app/Http/Controllers/User/PasswordController.php:15
* @route '/user/password'
*/
passwordForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: password.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\User\PasswordController::password
* @see app/Http/Controllers/User/PasswordController.php:15
* @route '/user/password'
*/
passwordForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: password.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

password.form = passwordForm

const user = {
    absen: Object.assign(absen, absenBc4e8c),
    rekapan: Object.assign(rekapan, rekapan),
    buktiMasuk: Object.assign(buktiMasuk, buktiMasuk),
    profile: Object.assign(profile, profile937a89),
    password: Object.assign(password, password9cfa90),
}

export default user