import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\SelfieVerificationController::approve
* @see app/Http/Controllers/Admin/SelfieVerificationController.php:12
* @route '/selfie-verifications/{selfieVerification}/approve'
*/
export const approve = (args: { selfieVerification: number | { id: number } } | [selfieVerification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: approve.url(args, options),
    method: 'patch',
})

approve.definition = {
    methods: ["patch"],
    url: '/selfie-verifications/{selfieVerification}/approve',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\SelfieVerificationController::approve
* @see app/Http/Controllers/Admin/SelfieVerificationController.php:12
* @route '/selfie-verifications/{selfieVerification}/approve'
*/
approve.url = (args: { selfieVerification: number | { id: number } } | [selfieVerification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { selfieVerification: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { selfieVerification: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            selfieVerification: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        selfieVerification: typeof args.selfieVerification === 'object'
        ? args.selfieVerification.id
        : args.selfieVerification,
    }

    return approve.definition.url
            .replace('{selfieVerification}', parsedArgs.selfieVerification.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SelfieVerificationController::approve
* @see app/Http/Controllers/Admin/SelfieVerificationController.php:12
* @route '/selfie-verifications/{selfieVerification}/approve'
*/
approve.patch = (args: { selfieVerification: number | { id: number } } | [selfieVerification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: approve.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Admin\SelfieVerificationController::approve
* @see app/Http/Controllers/Admin/SelfieVerificationController.php:12
* @route '/selfie-verifications/{selfieVerification}/approve'
*/
const approveForm = (args: { selfieVerification: number | { id: number } } | [selfieVerification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: approve.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\SelfieVerificationController::approve
* @see app/Http/Controllers/Admin/SelfieVerificationController.php:12
* @route '/selfie-verifications/{selfieVerification}/approve'
*/
approveForm.patch = (args: { selfieVerification: number | { id: number } } | [selfieVerification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: approve.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

approve.form = approveForm

/**
* @see \App\Http\Controllers\Admin\SelfieVerificationController::reject
* @see app/Http/Controllers/Admin/SelfieVerificationController.php:23
* @route '/selfie-verifications/{selfieVerification}/reject'
*/
export const reject = (args: { selfieVerification: number | { id: number } } | [selfieVerification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: reject.url(args, options),
    method: 'patch',
})

reject.definition = {
    methods: ["patch"],
    url: '/selfie-verifications/{selfieVerification}/reject',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\SelfieVerificationController::reject
* @see app/Http/Controllers/Admin/SelfieVerificationController.php:23
* @route '/selfie-verifications/{selfieVerification}/reject'
*/
reject.url = (args: { selfieVerification: number | { id: number } } | [selfieVerification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { selfieVerification: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { selfieVerification: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            selfieVerification: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        selfieVerification: typeof args.selfieVerification === 'object'
        ? args.selfieVerification.id
        : args.selfieVerification,
    }

    return reject.definition.url
            .replace('{selfieVerification}', parsedArgs.selfieVerification.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SelfieVerificationController::reject
* @see app/Http/Controllers/Admin/SelfieVerificationController.php:23
* @route '/selfie-verifications/{selfieVerification}/reject'
*/
reject.patch = (args: { selfieVerification: number | { id: number } } | [selfieVerification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: reject.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Admin\SelfieVerificationController::reject
* @see app/Http/Controllers/Admin/SelfieVerificationController.php:23
* @route '/selfie-verifications/{selfieVerification}/reject'
*/
const rejectForm = (args: { selfieVerification: number | { id: number } } | [selfieVerification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: reject.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\SelfieVerificationController::reject
* @see app/Http/Controllers/Admin/SelfieVerificationController.php:23
* @route '/selfie-verifications/{selfieVerification}/reject'
*/
rejectForm.patch = (args: { selfieVerification: number | { id: number } } | [selfieVerification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: reject.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

reject.form = rejectForm

const selfieVerifications = {
    approve: Object.assign(approve, approve),
    reject: Object.assign(reject, reject),
}

export default selfieVerifications