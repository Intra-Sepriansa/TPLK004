import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AiAttendanceController::scan
* @see app/Http/Controllers/Admin/AiAttendanceController.php:17
* @route '/attendance-ai/scan'
*/
export const scan = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: scan.url(options),
    method: 'post',
})

scan.definition = {
    methods: ["post"],
    url: '/attendance-ai/scan',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AiAttendanceController::scan
* @see app/Http/Controllers/Admin/AiAttendanceController.php:17
* @route '/attendance-ai/scan'
*/
scan.url = (options?: RouteQueryOptions) => {
    return scan.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AiAttendanceController::scan
* @see app/Http/Controllers/Admin/AiAttendanceController.php:17
* @route '/attendance-ai/scan'
*/
scan.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: scan.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AiAttendanceController::scan
* @see app/Http/Controllers/Admin/AiAttendanceController.php:17
* @route '/attendance-ai/scan'
*/
const scanForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: scan.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AiAttendanceController::scan
* @see app/Http/Controllers/Admin/AiAttendanceController.php:17
* @route '/attendance-ai/scan'
*/
scanForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: scan.url(options),
    method: 'post',
})

scan.form = scanForm

const attendanceAi = {
    scan: Object.assign(scan, scan),
}

export default attendanceAi