import AbsensiController from './AbsensiController'
import ProfileController from './ProfileController'
import PasswordController from './PasswordController'

const User = {
    AbsensiController: Object.assign(AbsensiController, AbsensiController),
    ProfileController: Object.assign(ProfileController, ProfileController),
    PasswordController: Object.assign(PasswordController, PasswordController),
}

export default User