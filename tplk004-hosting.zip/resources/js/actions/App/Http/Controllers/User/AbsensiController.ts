import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\User\AbsensiController::create
* @see app/Http/Controllers/User/AbsensiController.php:25
* @route '/user/absen'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/user/absen',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\User\AbsensiController::create
* @see app/Http/Controllers/User/AbsensiController.php:25
* @route '/user/absen'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\AbsensiController::create
* @see app/Http/Controllers/User/AbsensiController.php:25
* @route '/user/absen'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\User\AbsensiController::create
* @see app/Http/Controllers/User/AbsensiController.php:25
* @route '/user/absen'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\User\AbsensiController::create
* @see app/Http/Controllers/User/AbsensiController.php:25
* @route '/user/absen'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\User\AbsensiController::create
* @see app/Http/Controllers/User/AbsensiController.php:25
* @route '/user/absen'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\User\AbsensiController::create
* @see app/Http/Controllers/User/AbsensiController.php:25
* @route '/user/absen'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\User\AbsensiController::store
* @see app/Http/Controllers/User/AbsensiController.php:50
* @route '/user/absen'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/user/absen',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\User\AbsensiController::store
* @see app/Http/Controllers/User/AbsensiController.php:50
* @route '/user/absen'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\AbsensiController::store
* @see app/Http/Controllers/User/AbsensiController.php:50
* @route '/user/absen'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\User\AbsensiController::store
* @see app/Http/Controllers/User/AbsensiController.php:50
* @route '/user/absen'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\User\AbsensiController::store
* @see app/Http/Controllers/User/AbsensiController.php:50
* @route '/user/absen'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\User\AbsensiController::rekapan
* @see app/Http/Controllers/User/AbsensiController.php:295
* @route '/user/rekapan'
*/
export const rekapan = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: rekapan.url(options),
    method: 'get',
})

rekapan.definition = {
    methods: ["get","head"],
    url: '/user/rekapan',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\User\AbsensiController::rekapan
* @see app/Http/Controllers/User/AbsensiController.php:295
* @route '/user/rekapan'
*/
rekapan.url = (options?: RouteQueryOptions) => {
    return rekapan.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\AbsensiController::rekapan
* @see app/Http/Controllers/User/AbsensiController.php:295
* @route '/user/rekapan'
*/
rekapan.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: rekapan.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\User\AbsensiController::rekapan
* @see app/Http/Controllers/User/AbsensiController.php:295
* @route '/user/rekapan'
*/
rekapan.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: rekapan.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\User\AbsensiController::rekapan
* @see app/Http/Controllers/User/AbsensiController.php:295
* @route '/user/rekapan'
*/
const rekapanForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: rekapan.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\User\AbsensiController::rekapan
* @see app/Http/Controllers/User/AbsensiController.php:295
* @route '/user/rekapan'
*/
rekapanForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: rekapan.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\User\AbsensiController::rekapan
* @see app/Http/Controllers/User/AbsensiController.php:295
* @route '/user/rekapan'
*/
rekapanForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: rekapan.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

rekapan.form = rekapanForm

/**
* @see \App\Http\Controllers\User\AbsensiController::buktiMasuk
* @see app/Http/Controllers/User/AbsensiController.php:334
* @route '/user/bukti-masuk'
*/
export const buktiMasuk = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: buktiMasuk.url(options),
    method: 'get',
})

buktiMasuk.definition = {
    methods: ["get","head"],
    url: '/user/bukti-masuk',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\User\AbsensiController::buktiMasuk
* @see app/Http/Controllers/User/AbsensiController.php:334
* @route '/user/bukti-masuk'
*/
buktiMasuk.url = (options?: RouteQueryOptions) => {
    return buktiMasuk.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\AbsensiController::buktiMasuk
* @see app/Http/Controllers/User/AbsensiController.php:334
* @route '/user/bukti-masuk'
*/
buktiMasuk.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: buktiMasuk.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\User\AbsensiController::buktiMasuk
* @see app/Http/Controllers/User/AbsensiController.php:334
* @route '/user/bukti-masuk'
*/
buktiMasuk.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: buktiMasuk.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\User\AbsensiController::buktiMasuk
* @see app/Http/Controllers/User/AbsensiController.php:334
* @route '/user/bukti-masuk'
*/
const buktiMasukForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: buktiMasuk.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\User\AbsensiController::buktiMasuk
* @see app/Http/Controllers/User/AbsensiController.php:334
* @route '/user/bukti-masuk'
*/
buktiMasukForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: buktiMasuk.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\User\AbsensiController::buktiMasuk
* @see app/Http/Controllers/User/AbsensiController.php:334
* @route '/user/bukti-masuk'
*/
buktiMasukForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: buktiMasuk.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

buktiMasuk.form = buktiMasukForm

const AbsensiController = { create, store, rekapan, buktiMasuk }

export default AbsensiController