import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\User\PasswordController::edit
* @see app/Http/Controllers/User/PasswordController.php:15
* @route '/user/password'
*/
export const edit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/user/password',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\User\PasswordController::edit
* @see app/Http/Controllers/User/PasswordController.php:15
* @route '/user/password'
*/
edit.url = (options?: RouteQueryOptions) => {
    return edit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\PasswordController::edit
* @see app/Http/Controllers/User/PasswordController.php:15
* @route '/user/password'
*/
edit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\User\PasswordController::edit
* @see app/Http/Controllers/User/PasswordController.php:15
* @route '/user/password'
*/
edit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\User\PasswordController::edit
* @see app/Http/Controllers/User/PasswordController.php:15
* @route '/user/password'
*/
const editForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\User\PasswordController::edit
* @see app/Http/Controllers/User/PasswordController.php:15
* @route '/user/password'
*/
editForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\User\PasswordController::edit
* @see app/Http/Controllers/User/PasswordController.php:15
* @route '/user/password'
*/
editForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\User\PasswordController::update
* @see app/Http/Controllers/User/PasswordController.php:28
* @route '/user/password'
*/
export const update = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/user/password',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\User\PasswordController::update
* @see app/Http/Controllers/User/PasswordController.php:28
* @route '/user/password'
*/
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\PasswordController::update
* @see app/Http/Controllers/User/PasswordController.php:28
* @route '/user/password'
*/
update.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\User\PasswordController::update
* @see app/Http/Controllers/User/PasswordController.php:28
* @route '/user/password'
*/
const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\User\PasswordController::update
* @see app/Http/Controllers/User/PasswordController.php:28
* @route '/user/password'
*/
updateForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

const PasswordController = { edit, update }

export default PasswordController