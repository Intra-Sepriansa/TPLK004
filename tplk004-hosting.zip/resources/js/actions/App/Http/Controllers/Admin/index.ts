import DashboardController from './DashboardController'
import CourseController from './CourseController'
import AttendanceSessionController from './AttendanceSessionController'
import AttendanceTokenController from './AttendanceTokenController'
import AttendanceLogController from './AttendanceLogController'
import AiAttendanceController from './AiAttendanceController'
import SelfieVerificationController from './SelfieVerificationController'
import SettingsController from './SettingsController'
import ReportController from './ReportController'

const Admin = {
    DashboardController: Object.assign(DashboardController, DashboardController),
    CourseController: Object.assign(CourseController, CourseController),
    AttendanceSessionController: Object.assign(AttendanceSessionController, AttendanceSessionController),
    AttendanceTokenController: Object.assign(AttendanceTokenController, AttendanceTokenController),
    AttendanceLogController: Object.assign(AttendanceLogController, AttendanceLogController),
    AiAttendanceController: Object.assign(AiAttendanceController, AiAttendanceController),
    SelfieVerificationController: Object.assign(SelfieVerificationController, SelfieVerificationController),
    SettingsController: Object.assign(SettingsController, SettingsController),
    ReportController: Object.assign(ReportController, ReportController),
}

export default Admin