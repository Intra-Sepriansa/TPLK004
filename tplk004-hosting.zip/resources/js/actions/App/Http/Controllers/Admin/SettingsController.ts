import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\SettingsController::update
* @see app/Http/Controllers/Admin/SettingsController.php:12
* @route '/settings'
*/
export const update = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/settings',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\SettingsController::update
* @see app/Http/Controllers/Admin/SettingsController.php:12
* @route '/settings'
*/
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SettingsController::update
* @see app/Http/Controllers/Admin/SettingsController.php:12
* @route '/settings'
*/
update.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Admin\SettingsController::update
* @see app/Http/Controllers/Admin/SettingsController.php:12
* @route '/settings'
*/
const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\SettingsController::update
* @see app/Http/Controllers/Admin/SettingsController.php:12
* @route '/settings'
*/
updateForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Admin\SettingsController::updateGeofence
* @see app/Http/Controllers/Admin/SettingsController.php:31
* @route '/settings/geofence'
*/
export const updateGeofence = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateGeofence.url(options),
    method: 'patch',
})

updateGeofence.definition = {
    methods: ["patch"],
    url: '/settings/geofence',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\SettingsController::updateGeofence
* @see app/Http/Controllers/Admin/SettingsController.php:31
* @route '/settings/geofence'
*/
updateGeofence.url = (options?: RouteQueryOptions) => {
    return updateGeofence.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SettingsController::updateGeofence
* @see app/Http/Controllers/Admin/SettingsController.php:31
* @route '/settings/geofence'
*/
updateGeofence.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateGeofence.url(options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Admin\SettingsController::updateGeofence
* @see app/Http/Controllers/Admin/SettingsController.php:31
* @route '/settings/geofence'
*/
const updateGeofenceForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateGeofence.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\SettingsController::updateGeofence
* @see app/Http/Controllers/Admin/SettingsController.php:31
* @route '/settings/geofence'
*/
updateGeofenceForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateGeofence.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateGeofence.form = updateGeofenceForm

const SettingsController = { update, updateGeofence }

export default SettingsController