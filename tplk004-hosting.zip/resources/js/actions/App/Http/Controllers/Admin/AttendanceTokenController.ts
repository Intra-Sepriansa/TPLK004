import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AttendanceTokenController::store
* @see app/Http/Controllers/Admin/AttendanceTokenController.php:14
* @route '/attendance-sessions/{attendanceSession}/token'
*/
export const store = (args: { attendanceSession: number | { id: number } } | [attendanceSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/attendance-sessions/{attendanceSession}/token',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AttendanceTokenController::store
* @see app/Http/Controllers/Admin/AttendanceTokenController.php:14
* @route '/attendance-sessions/{attendanceSession}/token'
*/
store.url = (args: { attendanceSession: number | { id: number } } | [attendanceSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { attendanceSession: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { attendanceSession: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            attendanceSession: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        attendanceSession: typeof args.attendanceSession === 'object'
        ? args.attendanceSession.id
        : args.attendanceSession,
    }

    return store.definition.url
            .replace('{attendanceSession}', parsedArgs.attendanceSession.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AttendanceTokenController::store
* @see app/Http/Controllers/Admin/AttendanceTokenController.php:14
* @route '/attendance-sessions/{attendanceSession}/token'
*/
store.post = (args: { attendanceSession: number | { id: number } } | [attendanceSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AttendanceTokenController::store
* @see app/Http/Controllers/Admin/AttendanceTokenController.php:14
* @route '/attendance-sessions/{attendanceSession}/token'
*/
const storeForm = (args: { attendanceSession: number | { id: number } } | [attendanceSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AttendanceTokenController::store
* @see app/Http/Controllers/Admin/AttendanceTokenController.php:14
* @route '/attendance-sessions/{attendanceSession}/token'
*/
storeForm.post = (args: { attendanceSession: number | { id: number } } | [attendanceSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

store.form = storeForm

const AttendanceTokenController = { store }

export default AttendanceTokenController