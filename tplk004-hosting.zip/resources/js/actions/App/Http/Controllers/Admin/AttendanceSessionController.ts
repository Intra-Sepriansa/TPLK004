import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AttendanceSessionController::store
* @see app/Http/Controllers/Admin/AttendanceSessionController.php:15
* @route '/attendance-sessions'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/attendance-sessions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AttendanceSessionController::store
* @see app/Http/Controllers/Admin/AttendanceSessionController.php:15
* @route '/attendance-sessions'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AttendanceSessionController::store
* @see app/Http/Controllers/Admin/AttendanceSessionController.php:15
* @route '/attendance-sessions'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AttendanceSessionController::store
* @see app/Http/Controllers/Admin/AttendanceSessionController.php:15
* @route '/attendance-sessions'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AttendanceSessionController::store
* @see app/Http/Controllers/Admin/AttendanceSessionController.php:15
* @route '/attendance-sessions'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Admin\AttendanceSessionController::update
* @see app/Http/Controllers/Admin/AttendanceSessionController.php:60
* @route '/attendance-sessions/{attendanceSession}'
*/
export const update = (args: { attendanceSession: number | { id: number } } | [attendanceSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/attendance-sessions/{attendanceSession}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\AttendanceSessionController::update
* @see app/Http/Controllers/Admin/AttendanceSessionController.php:60
* @route '/attendance-sessions/{attendanceSession}'
*/
update.url = (args: { attendanceSession: number | { id: number } } | [attendanceSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { attendanceSession: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { attendanceSession: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            attendanceSession: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        attendanceSession: typeof args.attendanceSession === 'object'
        ? args.attendanceSession.id
        : args.attendanceSession,
    }

    return update.definition.url
            .replace('{attendanceSession}', parsedArgs.attendanceSession.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AttendanceSessionController::update
* @see app/Http/Controllers/Admin/AttendanceSessionController.php:60
* @route '/attendance-sessions/{attendanceSession}'
*/
update.patch = (args: { attendanceSession: number | { id: number } } | [attendanceSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Admin\AttendanceSessionController::update
* @see app/Http/Controllers/Admin/AttendanceSessionController.php:60
* @route '/attendance-sessions/{attendanceSession}'
*/
const updateForm = (args: { attendanceSession: number | { id: number } } | [attendanceSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AttendanceSessionController::update
* @see app/Http/Controllers/Admin/AttendanceSessionController.php:60
* @route '/attendance-sessions/{attendanceSession}'
*/
updateForm.patch = (args: { attendanceSession: number | { id: number } } | [attendanceSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Admin\AttendanceSessionController::destroy
* @see app/Http/Controllers/Admin/AttendanceSessionController.php:102
* @route '/attendance-sessions/{attendanceSession}'
*/
export const destroy = (args: { attendanceSession: number | { id: number } } | [attendanceSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/attendance-sessions/{attendanceSession}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\AttendanceSessionController::destroy
* @see app/Http/Controllers/Admin/AttendanceSessionController.php:102
* @route '/attendance-sessions/{attendanceSession}'
*/
destroy.url = (args: { attendanceSession: number | { id: number } } | [attendanceSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { attendanceSession: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { attendanceSession: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            attendanceSession: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        attendanceSession: typeof args.attendanceSession === 'object'
        ? args.attendanceSession.id
        : args.attendanceSession,
    }

    return destroy.definition.url
            .replace('{attendanceSession}', parsedArgs.attendanceSession.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AttendanceSessionController::destroy
* @see app/Http/Controllers/Admin/AttendanceSessionController.php:102
* @route '/attendance-sessions/{attendanceSession}'
*/
destroy.delete = (args: { attendanceSession: number | { id: number } } | [attendanceSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Admin\AttendanceSessionController::destroy
* @see app/Http/Controllers/Admin/AttendanceSessionController.php:102
* @route '/attendance-sessions/{attendanceSession}'
*/
const destroyForm = (args: { attendanceSession: number | { id: number } } | [attendanceSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AttendanceSessionController::destroy
* @see app/Http/Controllers/Admin/AttendanceSessionController.php:102
* @route '/attendance-sessions/{attendanceSession}'
*/
destroyForm.delete = (args: { attendanceSession: number | { id: number } } | [attendanceSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

/**
* @see \App\Http\Controllers\Admin\AttendanceSessionController::activate
* @see app/Http/Controllers/Admin/AttendanceSessionController.php:52
* @route '/attendance-sessions/{attendanceSession}/activate'
*/
export const activate = (args: { attendanceSession: number | { id: number } } | [attendanceSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: activate.url(args, options),
    method: 'patch',
})

activate.definition = {
    methods: ["patch"],
    url: '/attendance-sessions/{attendanceSession}/activate',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\AttendanceSessionController::activate
* @see app/Http/Controllers/Admin/AttendanceSessionController.php:52
* @route '/attendance-sessions/{attendanceSession}/activate'
*/
activate.url = (args: { attendanceSession: number | { id: number } } | [attendanceSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { attendanceSession: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { attendanceSession: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            attendanceSession: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        attendanceSession: typeof args.attendanceSession === 'object'
        ? args.attendanceSession.id
        : args.attendanceSession,
    }

    return activate.definition.url
            .replace('{attendanceSession}', parsedArgs.attendanceSession.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AttendanceSessionController::activate
* @see app/Http/Controllers/Admin/AttendanceSessionController.php:52
* @route '/attendance-sessions/{attendanceSession}/activate'
*/
activate.patch = (args: { attendanceSession: number | { id: number } } | [attendanceSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: activate.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Admin\AttendanceSessionController::activate
* @see app/Http/Controllers/Admin/AttendanceSessionController.php:52
* @route '/attendance-sessions/{attendanceSession}/activate'
*/
const activateForm = (args: { attendanceSession: number | { id: number } } | [attendanceSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: activate.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AttendanceSessionController::activate
* @see app/Http/Controllers/Admin/AttendanceSessionController.php:52
* @route '/attendance-sessions/{attendanceSession}/activate'
*/
activateForm.patch = (args: { attendanceSession: number | { id: number } } | [attendanceSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: activate.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

activate.form = activateForm

/**
* @see \App\Http\Controllers\Admin\AttendanceSessionController::close
* @see app/Http/Controllers/Admin/AttendanceSessionController.php:95
* @route '/attendance-sessions/{attendanceSession}/close'
*/
export const close = (args: { attendanceSession: number | { id: number } } | [attendanceSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: close.url(args, options),
    method: 'patch',
})

close.definition = {
    methods: ["patch"],
    url: '/attendance-sessions/{attendanceSession}/close',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\AttendanceSessionController::close
* @see app/Http/Controllers/Admin/AttendanceSessionController.php:95
* @route '/attendance-sessions/{attendanceSession}/close'
*/
close.url = (args: { attendanceSession: number | { id: number } } | [attendanceSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { attendanceSession: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { attendanceSession: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            attendanceSession: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        attendanceSession: typeof args.attendanceSession === 'object'
        ? args.attendanceSession.id
        : args.attendanceSession,
    }

    return close.definition.url
            .replace('{attendanceSession}', parsedArgs.attendanceSession.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AttendanceSessionController::close
* @see app/Http/Controllers/Admin/AttendanceSessionController.php:95
* @route '/attendance-sessions/{attendanceSession}/close'
*/
close.patch = (args: { attendanceSession: number | { id: number } } | [attendanceSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: close.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Admin\AttendanceSessionController::close
* @see app/Http/Controllers/Admin/AttendanceSessionController.php:95
* @route '/attendance-sessions/{attendanceSession}/close'
*/
const closeForm = (args: { attendanceSession: number | { id: number } } | [attendanceSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: close.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AttendanceSessionController::close
* @see app/Http/Controllers/Admin/AttendanceSessionController.php:95
* @route '/attendance-sessions/{attendanceSession}/close'
*/
closeForm.patch = (args: { attendanceSession: number | { id: number } } | [attendanceSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: close.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

close.form = closeForm

const AttendanceSessionController = { store, update, destroy, activate, close }

export default AttendanceSessionController