import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\ReportController::exportMethod
* @see app/Http/Controllers/Admin/ReportController.php:14
* @route '/reports/attendance.csv'
*/
export const exportMethod = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(options),
    method: 'get',
})

exportMethod.definition = {
    methods: ["get","head"],
    url: '/reports/attendance.csv',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ReportController::exportMethod
* @see app/Http/Controllers/Admin/ReportController.php:14
* @route '/reports/attendance.csv'
*/
exportMethod.url = (options?: RouteQueryOptions) => {
    return exportMethod.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ReportController::exportMethod
* @see app/Http/Controllers/Admin/ReportController.php:14
* @route '/reports/attendance.csv'
*/
exportMethod.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\ReportController::exportMethod
* @see app/Http/Controllers/Admin/ReportController.php:14
* @route '/reports/attendance.csv'
*/
exportMethod.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportMethod.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\ReportController::exportMethod
* @see app/Http/Controllers/Admin/ReportController.php:14
* @route '/reports/attendance.csv'
*/
const exportMethodForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: exportMethod.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\ReportController::exportMethod
* @see app/Http/Controllers/Admin/ReportController.php:14
* @route '/reports/attendance.csv'
*/
exportMethodForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: exportMethod.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\ReportController::exportMethod
* @see app/Http/Controllers/Admin/ReportController.php:14
* @route '/reports/attendance.csv'
*/
exportMethodForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: exportMethod.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

exportMethod.form = exportMethodForm

/**
* @see \App\Http\Controllers\Admin\ReportController::exportAudit
* @see app/Http/Controllers/Admin/ReportController.php:60
* @route '/reports/audit.csv'
*/
export const exportAudit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportAudit.url(options),
    method: 'get',
})

exportAudit.definition = {
    methods: ["get","head"],
    url: '/reports/audit.csv',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ReportController::exportAudit
* @see app/Http/Controllers/Admin/ReportController.php:60
* @route '/reports/audit.csv'
*/
exportAudit.url = (options?: RouteQueryOptions) => {
    return exportAudit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ReportController::exportAudit
* @see app/Http/Controllers/Admin/ReportController.php:60
* @route '/reports/audit.csv'
*/
exportAudit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportAudit.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\ReportController::exportAudit
* @see app/Http/Controllers/Admin/ReportController.php:60
* @route '/reports/audit.csv'
*/
exportAudit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportAudit.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\ReportController::exportAudit
* @see app/Http/Controllers/Admin/ReportController.php:60
* @route '/reports/audit.csv'
*/
const exportAuditForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: exportAudit.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\ReportController::exportAudit
* @see app/Http/Controllers/Admin/ReportController.php:60
* @route '/reports/audit.csv'
*/
exportAuditForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: exportAudit.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\ReportController::exportAudit
* @see app/Http/Controllers/Admin/ReportController.php:60
* @route '/reports/audit.csv'
*/
exportAuditForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: exportAudit.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

exportAudit.form = exportAuditForm

const ReportController = { exportMethod, exportAudit, export: exportMethod }

export default ReportController