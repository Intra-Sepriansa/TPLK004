import Admin from './Admin'
import MahasiswaController from './MahasiswaController'
import Auth from './Auth'
import User from './User'
import Settings from './Settings'

const Controllers = {
    Admin: Object.assign(Admin, Admin),
    MahasiswaController: Object.assign(MahasiswaController, MahasiswaController),
    Auth: Object.assign(Auth, Auth),
    User: Object.assign(User, User),
    Settings: Object.assign(Settings, Settings),
}

export default Controllers