import MahasiswaAuthController from './MahasiswaAuthController'

const Auth = {
    MahasiswaAuthController: Object.assign(MahasiswaAuthController, MahasiswaAuthController),
}

export default Auth