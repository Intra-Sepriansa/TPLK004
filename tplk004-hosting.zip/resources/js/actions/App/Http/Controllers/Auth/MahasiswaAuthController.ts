import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Auth\MahasiswaAuthController::store
* @see app/Http/Controllers/Auth/MahasiswaAuthController.php:16
* @route '/login/mahasiswa'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/login/mahasiswa',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Auth\MahasiswaAuthController::store
* @see app/Http/Controllers/Auth/MahasiswaAuthController.php:16
* @route '/login/mahasiswa'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\MahasiswaAuthController::store
* @see app/Http/Controllers/Auth/MahasiswaAuthController.php:16
* @route '/login/mahasiswa'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Auth\MahasiswaAuthController::store
* @see app/Http/Controllers/Auth/MahasiswaAuthController.php:16
* @route '/login/mahasiswa'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Auth\MahasiswaAuthController::store
* @see app/Http/Controllers/Auth/MahasiswaAuthController.php:16
* @route '/login/mahasiswa'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Auth\MahasiswaAuthController::destroy
* @see app/Http/Controllers/Auth/MahasiswaAuthController.php:65
* @route '/logout/mahasiswa'
*/
export const destroy = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: destroy.url(options),
    method: 'post',
})

destroy.definition = {
    methods: ["post"],
    url: '/logout/mahasiswa',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Auth\MahasiswaAuthController::destroy
* @see app/Http/Controllers/Auth/MahasiswaAuthController.php:65
* @route '/logout/mahasiswa'
*/
destroy.url = (options?: RouteQueryOptions) => {
    return destroy.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\MahasiswaAuthController::destroy
* @see app/Http/Controllers/Auth/MahasiswaAuthController.php:65
* @route '/logout/mahasiswa'
*/
destroy.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: destroy.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Auth\MahasiswaAuthController::destroy
* @see app/Http/Controllers/Auth/MahasiswaAuthController.php:65
* @route '/logout/mahasiswa'
*/
const destroyForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Auth\MahasiswaAuthController::destroy
* @see app/Http/Controllers/Auth/MahasiswaAuthController.php:65
* @route '/logout/mahasiswa'
*/
destroyForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(options),
    method: 'post',
})

destroy.form = destroyForm

const MahasiswaAuthController = { store, destroy }

export default MahasiswaAuthController