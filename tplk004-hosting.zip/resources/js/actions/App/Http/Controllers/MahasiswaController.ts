import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\MahasiswaController::store
* @see app/Http/Controllers/MahasiswaController.php:38
* @route '/mahasiswa'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/mahasiswa',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\MahasiswaController::store
* @see app/Http/Controllers/MahasiswaController.php:38
* @route '/mahasiswa'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MahasiswaController::store
* @see app/Http/Controllers/MahasiswaController.php:38
* @route '/mahasiswa'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\MahasiswaController::store
* @see app/Http/Controllers/MahasiswaController.php:38
* @route '/mahasiswa'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\MahasiswaController::store
* @see app/Http/Controllers/MahasiswaController.php:38
* @route '/mahasiswa'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\MahasiswaController::exportMethod
* @see app/Http/Controllers/MahasiswaController.php:13
* @route '/mahasiswa/export.csv'
*/
export const exportMethod = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(options),
    method: 'get',
})

exportMethod.definition = {
    methods: ["get","head"],
    url: '/mahasiswa/export.csv',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MahasiswaController::exportMethod
* @see app/Http/Controllers/MahasiswaController.php:13
* @route '/mahasiswa/export.csv'
*/
exportMethod.url = (options?: RouteQueryOptions) => {
    return exportMethod.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MahasiswaController::exportMethod
* @see app/Http/Controllers/MahasiswaController.php:13
* @route '/mahasiswa/export.csv'
*/
exportMethod.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\MahasiswaController::exportMethod
* @see app/Http/Controllers/MahasiswaController.php:13
* @route '/mahasiswa/export.csv'
*/
exportMethod.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportMethod.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\MahasiswaController::exportMethod
* @see app/Http/Controllers/MahasiswaController.php:13
* @route '/mahasiswa/export.csv'
*/
const exportMethodForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: exportMethod.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\MahasiswaController::exportMethod
* @see app/Http/Controllers/MahasiswaController.php:13
* @route '/mahasiswa/export.csv'
*/
exportMethodForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: exportMethod.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\MahasiswaController::exportMethod
* @see app/Http/Controllers/MahasiswaController.php:13
* @route '/mahasiswa/export.csv'
*/
exportMethodForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: exportMethod.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

exportMethod.form = exportMethodForm

/**
* @see \App\Http\Controllers\MahasiswaController::destroy
* @see app/Http/Controllers/MahasiswaController.php:56
* @route '/mahasiswa/{mahasiswa}'
*/
export const destroy = (args: { mahasiswa: number | { id: number } } | [mahasiswa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/mahasiswa/{mahasiswa}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\MahasiswaController::destroy
* @see app/Http/Controllers/MahasiswaController.php:56
* @route '/mahasiswa/{mahasiswa}'
*/
destroy.url = (args: { mahasiswa: number | { id: number } } | [mahasiswa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { mahasiswa: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { mahasiswa: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            mahasiswa: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        mahasiswa: typeof args.mahasiswa === 'object'
        ? args.mahasiswa.id
        : args.mahasiswa,
    }

    return destroy.definition.url
            .replace('{mahasiswa}', parsedArgs.mahasiswa.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\MahasiswaController::destroy
* @see app/Http/Controllers/MahasiswaController.php:56
* @route '/mahasiswa/{mahasiswa}'
*/
destroy.delete = (args: { mahasiswa: number | { id: number } } | [mahasiswa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\MahasiswaController::destroy
* @see app/Http/Controllers/MahasiswaController.php:56
* @route '/mahasiswa/{mahasiswa}'
*/
const destroyForm = (args: { mahasiswa: number | { id: number } } | [mahasiswa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\MahasiswaController::destroy
* @see app/Http/Controllers/MahasiswaController.php:56
* @route '/mahasiswa/{mahasiswa}'
*/
destroyForm.delete = (args: { mahasiswa: number | { id: number } } | [mahasiswa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const MahasiswaController = { store, exportMethod, destroy, export: exportMethod }

export default MahasiswaController